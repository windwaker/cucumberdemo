package PageObjects;

import Utilities.WaitHelper;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class DashboardPage {

    public WebDriver driver;
    private WaitHelper waitHelper;

    public DashboardPage(WebDriver driver){
        this.driver = driver;
        //PageFactory.initElements(driver, this);
        waitHelper = new WaitHelper(driver);
    }

    private By logout = By.cssSelector("body > div.wrapper > div.main-header > div > div > ul > li:nth-child(3) > a");

    // Define the locators
    private By customerMenu = By.cssSelector("body > div.wrapper > div.main-sidebar > div > ul > li:nth-child(4) > a > span");
    private By customerMenuItem = By.cssSelector("body > div.wrapper > div.main-sidebar > div > ul > li.treeview.menu-open > ul > li:nth-child(1) > a > span");

    public void clickOnCustomerMenu(){
        WebElement we = driver.findElement(customerMenu);
        waitHelper.waitForElement(we, 10);
        we.click();
    }

    public void clickOnCustomerMenuItem(){
        driver.findElement(customerMenuItem).click();
    }

    public String getPageTitle() {
        return driver.getTitle();
    }

    public void logout(){
        driver.findElement(logout).click();
    }
}
