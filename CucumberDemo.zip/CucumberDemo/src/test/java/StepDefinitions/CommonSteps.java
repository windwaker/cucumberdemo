package StepDefinitions;

import PageObjects.CustomerPage;
import PageObjects.DashboardPage;
import PageObjects.LoginPage;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;

public class CommonSteps {

    public static Logger logger;

    public WebDriver driver;

    // Pages we need to reference
    public LoginPage loginPage;
    public DashboardPage dashboardPage;
    public CustomerPage customerPage;
}
