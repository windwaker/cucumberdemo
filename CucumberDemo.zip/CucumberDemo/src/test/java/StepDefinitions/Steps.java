package StepDefinitions;

import PageObjects.DashboardPage;
import PageObjects.LoginPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.junit.Assert;
import org.openqa.selenium.chrome.ChromeDriver;

public class Steps extends CommonSteps{

    // Login Page

    @Given("User launches chrome browser")
    public void user_launches_chrome_browser() {
        // https://www.youtube.com/watch?v=rbuR9Q_55h4
        logger = LogManager.getLogger("Steps.class");
        System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/drivers/chromedriver");
        logger.info("Initialising Driver ...");
        driver = new ChromeDriver();
        loginPage = new LoginPage(driver);
        dashboardPage = new DashboardPage(driver);
    }

    @When("User opens url {string}")
    public void user_opens_url(String url) {
        driver.get(url);
    }

    @When("User enters Email as {string} and Password as {string}")
    public void user_enters_email_as_and_password_as(String email, String password) {
        loginPage.setUserName(email);
        loginPage.setPassword(password);
    }

    @When("Click on login")
    public void click_on_login() {
        loginPage.login();
    }

    @Then("Page title should be {string}")
    public void page_title_should_be(String title) {
        if(driver.getPageSource().contains("Login was unsuccessful.")){
            driver.close();
            Assert.fail();
        } else {
            Assert.assertEquals(title, driver.getTitle());
        }
    }

    @When("User click on Log out link")
    public void user_click_on_log_out_link() throws InterruptedException {
        dashboardPage.logout();
        Thread.sleep(3000);
    }

    @Then("Close browser")
    public void close_browser() {
        driver.close();
        driver.quit();
    }

    // Customers

    @Then("User can view dashboard")
    public void user_can_view_dashboard() {
        Assert.assertEquals("Dashboard / nopCommerce administration", dashboardPage.getPageTitle());
    }

    @When("User clicks on customers menu")
    public void user_clicks_on_customers_menu() throws InterruptedException {
        Thread.sleep(3000);
        dashboardPage.clickOnCustomerMenu();
        Thread.sleep(3000);
        dashboardPage.clickOnCustomerMenuItem();
    }

    @When("User clicks on customers menu item")
    public void user_clicks_on_customers_menu_item() {

    }

    @When("User clicks on add new button")
    public void user_clicks_on_add_new_button() {

    }

    @Then("User can view add new customer page")
    public void user_can_view_add_new_customer_page() {

    }

    @When("User enters customer info")
    public void user_enters_customer_info() {

    }

    @When("User clicks on save button")
    public void user_clicks_on_save_button() {

    }

    @Then("User can view confirmation message {string}")
    public void user_can_view_confirmation_message(String string) {

    }
}
