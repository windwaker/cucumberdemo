package TestRunner;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

// https://testingneeds.wordpress.com/2015/09/15/junit-runner-with-cucumberoptions/

@RunWith(Cucumber.class)
@CucumberOptions(
        features = ".//features/Customers.feature",
        glue = "StepDefinitions",
        dryRun = false,
        monochrome = false,
        plugin = {"pretty", "html:test-output.html"}
)
public class TestRunner {

}
