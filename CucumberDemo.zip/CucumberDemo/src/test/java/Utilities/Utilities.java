package Utilities;

import com.github.javafaker.Address;
import com.github.javafaker.Faker;
import com.github.javafaker.service.FakeValuesService;
import com.github.javafaker.service.RandomService;

import java.util.Locale;

public class Utilities {

    // https://github.com/DiUS/java-faker

    FakeValuesService fakeValuesService;

    public Utilities(){
        fakeValuesService = new FakeValuesService(new Locale("en-IE"), new RandomService());
    }

    public static String randomString(Integer length){
        return "";
    }

    public static void main(String[] args) {
        Utilities u = new Utilities();
        String s1 = null;
        String s2 = null;
        Address a1 = null;
        try {
            s1 = u.generateRandomGmailAddress();
            s2 = u.generateStringBasedOnRegex("[a-z1-9]{10}");
            a1 = u.generateFakeAddress(new Locale("en-US"));
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println(s1);
        System.out.println(s2);
        System.out.println(a1.zipCodeByState("NY"));
    }

    public String generateRandomGmailAddress() {
        return fakeValuesService.bothify("????##@gmail.com");
    }

    public String generateStringBasedOnRegex(String regex){
        return fakeValuesService.regexify(regex);
    }

    public Address generateFakeAddress(Locale locale) {
        return new Faker(locale).address();
    }
}
