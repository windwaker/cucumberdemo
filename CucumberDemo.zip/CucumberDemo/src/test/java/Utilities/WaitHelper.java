package Utilities;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.function.Function;
import java.util.function.Predicate;

public class WaitHelper {

    public WebDriver driver;

    public WaitHelper(WebDriver driver){
        this.driver = driver;
    }



    public void waitForElement(WebElement element, long timeOut){
        WebDriverWait wait = new WebDriverWait(driver, timeOut);
        wait.until(ExpectedConditions.visibilityOf(element));
    }

    /**
     * Investigate use of Lambda to simplify number of "wait" methods
     * https://stackoverflow.com/questions/31102351/selenium-java-lambda-implementation-for-explicit-waits
     * @param func
     * @param timeOut
     */
    public void waitViaFunction(Function func, long timeOut){
        /*
            WebElement we =
                    new WebDriverWait(driver, 5)
                            .until((WebDriver driver) -> driver.findElement(By.id("q")));
        */
        WebDriverWait wait = new WebDriverWait(driver, timeOut);
        wait.until(func);
    }

}
